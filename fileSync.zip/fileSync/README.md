To get started, please Create/Open and edit the config.ini file in the same directory as the jar file and add the following functionality.


##############################start of the file######################
@host==192.168.1.251
@username=<username>
@password=<password>
@folder_to_watch=/path/to/folder
@temp_folder=/path/to/folder
@remoteFolder=/path/to/remote/folder
##########################end of configuration file#################

for example here's mine running on my local PC

#########################comments start with a hash
#please ensure that these parameters remain in the order you see them, 
#simply fill in your details
@host=localhost
@username=douglas
@password=justin
@folder_to_watch=/home/douglas/Music
@temp_folder=/home/douglas/Desktop/TempFolder
@remoteFolder=/home/douglas/backUps
########################################################################


You can just paste the code between the ##### symbols and change parameters on the right of the '=' sign to match your requirements.


To add this service as a Windows service or Linux cron job, here is what you can do.

##For Linux..
	open and edit the cron.daily file as follows
	
